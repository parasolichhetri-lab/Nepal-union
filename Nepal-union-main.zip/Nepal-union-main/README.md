<!doctype html>
<html lang="ne">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Nepali Union — नेपाली श्रमिक सहायता</title>
  <style>
    :root{--accent:#DC143C;--bg:#fff;--muted:#666}
    body{font-family: 'Noto Sans', system-ui, -apple-system, sans-serif;margin:0;background:var(--bg);color:#111}
    header{background:linear-gradient(90deg,#fff 0%, #ffdfe6 100%);border-bottom:4px solid var(--accent)}
    .container{max-width:980px;margin:0 auto;padding:18px}
    .brand{display:flex;align-items:center;gap:12px}
    .logo{width:56px;height:56px;border-radius:8px;background:var(--accent);display:flex;align-items:center;justify-content:center;color:white;font-weight:700}
    h1{margin:0;font-size:20px}
    nav{margin-top:10px}
    nav a{margin-right:12px;text-decoration:none;color:var(--accent);font-weight:600}
    .hero{display:flex;flex-direction:column;gap:12px;padding:22px 0}
    .card{background:#fff;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,0.06);padding:16px}
    .grid{display:grid;grid-template-columns:1fr 380px;gap:18px}
    @media(max-width:880px){.grid{grid-template-columns:1fr} }
    button, .btn{background:var(--accent);color:white;border:none;padding:10px 14px;border-radius:8px;cursor:pointer;text-decoration:none;display:inline-block;text-align:center}
    .muted{color:var(--muted)}
    form label{display:block;margin-top:10px;font-weight:600}
    input, textarea, select{width:100%;padding:10px;border-radius:8px;border:1px solid #e6e6e6;margin-top:6px}
    footer{padding:20px;text-align:center;color:var(--muted);font-size:13px}
    .hotline{display:flex;flex-direction:column;gap:8px}
    .hotline a{color:var(--accent);font-weight:700;text-decoration:none}
    .danger{background:#fff4f4;border:1px solid #ffd6d6;padding:12px;border-radius:8px}
    .small{font-size:13px;color:var(--muted)}
  </style>
</head>
<body>
  <header>
    <div class="container">
      <div class="brand">
        <div class="logo">NU</div>
        <div>
          <h1>नेपाली यूनियन — नेपाली श्रमिक सहायता</h1>
          <div class="small">भारतमा काम गर्ने नेपाली श्रमिकहरूको लागि सुरक्षा, रिपोर्ट र सहयोग</div>
        </div>
      </div>
      <nav>
        <a href="#home">गृह</a>
        <a href="#about">हाम्रो बारेमा</a>
        <a href="#report">रिपोर्ट गर्नुहोस्</a>
        <a href="#resources">स्रोत</a>
        <a href="#contact">सम्पर्क</a>
      </nav>
    </div>
  </header>

  <main class="container">
    <section id="home" class="hero">
      <div class="card">
        <h2>तुरुन्त सहयोग चाहिन्छ?</h2>
        <p class="muted">यदि तपाईंलाई अहिले खतरामा हुनुहुन्छ भने तुरुन्त फोन गर्नुहोस्: <strong>112</strong> (भारत) — पुलिस/एम्बुलेन्स/आगो।</p>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
          <a class="btn" href="tel:112">अब फोन गर्नुहोस् (112)</a>
          <a class="btn" href="mailto:parasholee716@gmail.com">हामीलाइ इमेल गर्नुहोस्</a>
          <a class="btn" href="https://wa.me/9779748720249" target="_blank">WhatsApp सम्पर्क</a>
        </div>
      </div>
    </section>

    <section class="grid" style="margin-top:18px">
      <div>
        <div class="card">
          <h3 id="about">हाम्रो बारेमा</h3>
          <p>नेपाली यूनियन भारतमा रहेका नेपाली श्रमिकहरूका लागि एक निःशुल्क सहयोग प्लेटफर्म हो। हामी तिनीहरूलाई कानुनी सल्लाह, आपत्कालीन सम्पर्क, र स्थानीय एनजीओसँग जोड्ने काम गर्छौं। यदि कुनै मालिकले तपाईंलाई दुव्र्यवहार गर्छ भने तपाईं यो साइटबाट रिपोर्ट गर्न सक्नुहुन्छ।</p>

          <h4>के हामी गर्द्छौं?</h4>
          <ul>
            <li>अनाम रिपोर्ट स्वीकार गर्छौं</li>
            <li>आपत्कालीन नम्बर र दूतावास सम्पर्क साझा गर्छौं</li>
            <li>स्वयंसेवक र दानको माध्यमबाट समर्थन जुटाउँछौं</li>
          </ul>

          <div style="margin-top:10px" class="danger">
            <strong>नोट:</strong> सुरक्षा प्राथमिकता हो। रिपोर्ट गर्दा व्यक्तिगत जानकारी दिँदा सतर्क हुनुहोस् — यदि तपाईं सुरक्षित रहन सक्नुहुन्न भने अनाम रूपमा रिपोर्ट गर्नुहोस्।
          </div>
        </div>

        <div style="margin-top:14px" class="card">
          <h3 id="resources">आवश्यक हेल्पलाइन र स्रोत</h3>
          <div class="hotline">
            <div><strong>बृहत्तर आपत्कालिन (India):</strong> 112</div>
            <div><strong>महिला हेल्पलाइन (India):</strong> 1091</div>
            <div><strong>Childline (बाल सहायता):</strong> 1098</div>
            <div><strong>दूतावास / कन्सुलेट:</strong> कृपया हालसालैको सम्पर्क नम्बरको लागि नजिकको नेपाली दूतावास/कन्सुलेट वेबसाइट जाँच गर्नुहोस्।</div>
          </div>
        </div>
      </div>

      <aside>
        <div class="card">
          <h3 id="report">रिपोर्ट फारम</h3>
          <p class="small">निम्न फारम भरी हामीलाई जानकारी पठाउनुहोस्। फारमले तपाईंको रिपोर्ट <strong>parasholee716@gmail.com</strong> मा पठाउने प्राथमिकता राख्छ (Formspree वा इमेल fallback). फारम प्रयोग गर्न, कृपया आवश्यक जानकारी दिनुहोस् — तपाईंले चाहनु भयो भने नाम खाली छोड्न सक्नुहुन्छ।</p>

          <form id="reportForm" class="report" method="POST" action="https://formspree.io/f/REPLACE_WITH_YOUR_FORM_ID" enctype="multipart/form-data">
            <label>तपाईंको नाम (वैकल्पिक)</label>
            <input name="name" placeholder="नाम (यदि चाहनुहुन्छ)" />

            <label>फोन / WhatsApp (वैकल्पिक)</label>
            <input name="phone" placeholder="+91XXXXXXXXXX" />

            <label>ठेगाना / कहाँ भइरहेको छ</label>
            <input name="location" placeholder="नगर / राज्य" required />

            <label>समस्याको विवरण</label>
            <textarea name="message" rows="5" placeholder="यहाँ सहि-समस्या र मिति/समय लेख्नुहोस्" required></textarea>

            <label>सहायक फाइल (छवि वा दस्तावेज) — वैकल्पिक</label>
            <input type="file" name="attachment" accept="image/*,.pdf" />

            <div style="margin-top:10px;display:flex;gap:8px">
              <button type="submit">रिपोर्ट पठाउनुहोस्</button>
              <button type="button" id="mailtoBtn" class="btn">इमेल पठाउने विकल्प</button>
            </div>

            <p id="status" class="small muted"></p>
          </form>

          <script>
            document.getElementById('reportForm').addEventListener('submit', async function(e){
              var action = e.target.action;
              if(action.includes('REPLACE_WITH_YOUR_FORM_ID')){
                e.preventDefault();
                document.getElementById('status').textContent = 'Formspree ID छैन — इमेल fallback प्रयोग गरिँदै...';
                sendMailFallback();
              } else {
                document.getElementById('status').textContent = 'पठाइँ भइरहेको छ...';
              }
            });

            function sendMailFallback(){
              var f = document.getElementById('reportForm');
              var name = encodeURIComponent(f.name.value || 'अनाम');
              var phone = encodeURIComponent(f.phone.value || 'नबोधाइएको');
              var loc = encodeURIComponent(f.location.value || 'नबोधाइएको');
              var msg = encodeURIComponent(f.message.value || 'पटकथा रिपोर्ट');
              var body = 'नाम: ' + name + '\nफोन/WhatsApp: ' + phone + '\nठेगाना: ' + loc + '\n\nविवरण:\n' + msg;
              var mailto = 'mailto:parasholee716@gmail.com?subject=' + encodeURIComponent('Nepali Union रिपोर्ट') + '&body=' + body;
              window.location.href = mailto;
            }

            document.getElementById('mailtoBtn').addEventListener('click', sendMailFallback);
          </script>

        </div>

        <div style="margin-top:12px" class="card">
          <h3 id="contact">सम्पर्क</h3>
          <p>रिपोर्ट प्राप्ति इमेल: <strong>parasholee716@gmail.com</strong></p>
          <p>WhatsApp सम्पर्क: <a href="https://wa.me/9779748720249" target="_blank">+977 9748720249</a></p>

          <h4>दान र स्वयंसेवक</h4>
          <p class="small">हामी भविष्यमा दान र स्वयंसेवक पृष्ठ जोड्ने तयारीमा छौं। प्रारम्भमा, कृपया इमेल वा WhatsApp मार्फत सम्पर्क गर्नुहोस्।</p>
        </div>
      </aside>
    </section>

  </main>

  <footer>
    <div class="container">
      <div>Nepali Union — सबै अधिकार सुरक्षित छैनन् · विकास: Parash Olee</div>
      <div class="small">यो साइटले आधिकारिक कानूनी सल्लाह गर्दैन। आपतकालमा 112 डायल गर्नुहोस्।</div>
    </div>
  </footer>

  <!-- HOW TO PUBLISH FOR FREE -->
  <!--
    1) GitHub Pages:
       - Create a GitHub account (github.com).
       - Create a new public repository and upload this file as 'index.html'.
       - Go to Settings → Pages → set branch to main → save.
       - Site URL: https://<your-username>.github.io/<repo-name>/

    2) Netlify:
       - Create account at https://netlify.com
       - Drag this file to 'New site from drag & drop'.
       - Site will go live instantly with free HTTPS.

    3) Formspree setup:
       - Sign up at https://formspree.io
       - Create a form → copy its endpoint (e.g., https://formspree.io/f/abcxyz)
       - Replace in the <form> action above.
  -->
</body>
</html>
